## claim insurance acc
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* accident
  - utter_question2
* serious
  - utter_question3
* answer3
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye 

## claim insurance acc1
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* accident
  - utter_question2
* serious
  - utter_question3
* answer3
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye 
  
## claim insurance acc2
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* accident
  - utter_question2
* serious
  - utter_question3
* answer3
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye 

## claim insurance heal
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* health
  - utter_question2
* serious
  - utter_question3
* answer3 
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye

## claim insurance heal1
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* health
  - utter_question2
* serious
  - utter_question3
* answer3 
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye

## claim insurance heal2
* greet
  - utter_selfintroduction
* claim
  - utter_request
* affirm
  - utter_question1
* health
  - utter_question2
* serious
  - utter_question3
* answer3 
  - utter_question4
* proff
  - action_predict
* thank
  - utter_goodbye

## claim insurance fstop
  - utter_greet
* greet
  - utter_selfintroduction
* deny
  - utter_goodbye

## claim insurance sstop
  - utter_greet
* greet
  - utter_selfintroduction
* claim
  - utter_request
* deny
  - utter_goodbye

## bot challenge
* bot_challenge
  - utter_iamabot
