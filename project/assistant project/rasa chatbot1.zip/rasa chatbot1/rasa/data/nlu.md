## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:accident
- It was a very bad accident
- I got dashed by a car
- It was an accident
- accident

## intent:health
- it was an improper health condition
- improper heatlth
- improper health condition

## intent:serious
- very serious
- serious
- yes very serious
- yes serious
- not very serious
- not serious at all
- normal

## intent:proff
- govt
- private
- corporate
- corp
- pvt

## intent:claim
- sure
- can I claim my insurance?
- I want to know about my insurance
- tell me about mine
- help me to know my claim status

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:thank
-  thank you 
-  oh it's fine
-  very nice
-  my luck
-  bad luck
-  that is not what i was expecting
-  as expected 

## intent:affirm
- yes
- please continue
- yep
- indeed
- okay
- of course
- carry on
- that sounds good


## intent:answer3
- yes, there was a minor one
- no, there was none
- maybe
- there was one
- yeah, very small illness
- there were no problems

## intent:deny
- nope
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?
